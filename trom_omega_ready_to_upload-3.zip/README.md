# Trom Omega Website

## Upload to GitHub Pages

1. Create a public repository named `YOURUSERNAME.github.io`.
2. Upload `index.html` and the entire `images` folder.
3. Go to Settings -> Pages.
4. Select Deploy from a branch, choose `main` and `/ (root)`, then Save.
5. Your site will be available at `https://YOURUSERNAME.github.io`.

Replace YOURUSERNAME with your GitHub username.
